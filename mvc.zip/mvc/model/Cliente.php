<?php
class Cliente{
    
    private $id;
    private $cpf;
    private $nome;

    private $con;

    // O MÉTODO CONSTRUTOR DA CLASSE É O MÉTODO DISPARADO AUTOMATICAMENTE
    public function __construct(){
        // CONEXÃO COM O BANCO DE DADOS
        $this->con = new PDO(SERVIDOR, USUARIO, SENHA);        
    }
    
    // O GET RECUPERA
	public function getId() {
		return $this->id;
	}

    // O SET SALVA
	public function setId($id) {
		$this->id = $id;
	}

    public function getCpf() {
        return $this->cpf;
    }

    public function setCpf($cpf){
        $this->cpf = $cpf;
    }

	public function getNome() {
		return $this->nome;
	}

	public function setNome($nome) {
		$this->nome = $nome;
	}
}


