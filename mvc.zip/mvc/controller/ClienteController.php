<?php
class ClienteController{

    public function teste(){

        // INSTANCIANDO O OBJETO cliente DA CLASSE Cliente
        $cliente = new Cliente();

        // ATRIBUINDO VALORES AOS ATRIBUTOS DA CLASSE
        $cliente->setId(1);
        $cliente->setCpf('022.831.640-52');
        $cliente->setNome('Maria do Rosário');

        // RECUPERANDO O VALORES DOS ATRIBUTOS E MOSTRANDO NA TELA
        include "view/cliente.php";

    }

}