<?php

define("SERVIDOR", "mysql:host=localhost; port=3306; dbname=blog; charset=utf8");
define("USUARIO", "ROOT");
define("SENHA", "");
